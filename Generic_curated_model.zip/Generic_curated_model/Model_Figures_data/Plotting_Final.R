
rm(list = ls())
library(magrittr)
library(dbplyr)
library(dplyr)
library(ggplot2)

directory = "C:/Users/alexe/OneDrive - Universiteit Leiden/mcsim_files/Generic_curated_model/Model_Figures_data"

file_name <- list.files(path = paste0(directory),pattern = ".txt")

myfiles = lapply(paste0(directory,"/",file_name), read.delim,sep=" ")
names(myfiles) <- file_name

repeated_dosing_32 = myfiles[c("Andrographolide_R_8_24.txt",  "Sulforaphane_R_8_24.txt", "CDDO_me_R_8_24.txt", "Ethacrynic_Acid_R_8_24.txt" )]
repeated_dosing_48 = myfiles[c("Andrographolide_R_24_24.txt",  "Sulforaphane_R_24_24.txt" , "CDDO_me_R_24_24.txt", "Ethacrynic_Acid_R_24_24.txt" )]


repeated_dosing_32$Andrographolide_R_8_24.txt$Treament = rep("Andro", length(repeated_dosing_32$Andrographolide_R_8_24.txt$Srxn1_max))
repeated_dosing_32$Sulforaphane_R_8_24.txt$Treament = rep("Sul", length(repeated_dosing_32$Andrographolide_R_8_24.txt$Srxn1_max))
repeated_dosing_32$CDDO_me_R_8_24.txt$Treament = rep("CDDO", length(repeated_dosing_32$Andrographolide_R_8_24.txt$Srxn1_max))
repeated_dosing_32$Ethacrynic_Acid_R_8_24.txt$Treament = rep("ETA", length(repeated_dosing_32$Andrographolide_R_8_24.txt$Srxn1_max))

Df = do.call("rbind", list(repeated_dosing_32$Andrographolide_R_8_24.txt,repeated_dosing_32$Sulforaphane_R_8_24.txt,repeated_dosing_32$CDDO_me_R_8_24.txt,repeated_dosing_32$Ethacrynic_Acid_R_8_24.txt))

Df$Experiment = rep("8_24",length(Df$NRF2_max))


repeated_dosing_48$Andrographolide_R_24_24.txt$Treament = rep("Andro", length(repeated_dosing_48$Andrographolide_R_24_24.txt$Srxn1_max))
repeated_dosing_48$Sulforaphane_R_24_24.txt$Treament = rep("Sul", length(repeated_dosing_48$Sulforaphane_R_24_24.txt$Srxn1_max))
repeated_dosing_48$CDDO_me_R_24_24.txt$Treament = rep("CDDO", length(repeated_dosing_48$Sulforaphane_R_24_24.txt$Srxn1_max))
repeated_dosing_48$Ethacrynic_Acid_R_24_24.txt$Treament = rep("ETA", length(repeated_dosing_48$Ethacrynic_Acid_R_24_24.txt$Srxn1_max))

Df1 = do.call("rbind", list(repeated_dosing_48$Andrographolide_R_24_24.txt,repeated_dosing_48$Sulforaphane_R_24_24.txt,repeated_dosing_48$CDDO_me_R_24_24.txt,repeated_dosing_48$Ethacrynic_Acid_R_24_24.txt))

Df1$Experiment = rep("24_24",length(Df1$NRF2_max))

Finalplotdata = do.call("rbind", list(Df, Df1))

final = data.frame(Finalplotdata)
glimpse(Finalplotdata)

unique(Finalplotdata$Treament)

Drug = unique(Finalplotdata$Treament)
Exp = unique(Finalplotdata$Experiment)  # 1 for  "8_24" and 2 for 24_24 

Drug = c("Sul" ,"Andro","ETA","CDDO")
Dose1 = c(0.35,0.1,1,0.1)


for (i in 1:4){
  for (j in 1:2){
plot = final %>% filter(.,Treament == Drug[i]) %>% filter(.,Experiment == Exp[j]) %>% 
  ggplot() +
  geom_line(aes(x = time, y = Srxn1_max, color = "Simulated_max"),size=1) +
  geom_line(aes(x = time, y = Srxn1_mean, color="Simulated_mean"),size=1) +
  geom_line(aes(x = time, y = Srxn1_min, color="Simulated_min"),size=1) +
  geom_errorbar(aes(x = time, ymin=SRXN1_observed-SRXN1_SD, ymax= SRXN1_observed +SRXN1_SD,color = "Experiments_mean(Sd)"), size=0.5,   
                width=.25) + 
  facet_grid(dose2~dose1) +
  labs(x = "Time (hrs)",y="GFP intensity",sec.x="First exposure (�M)",
       sec.y="Second exposure (�M)", title = paste0(Exp[j],"_", Drug[i],"_Srxn1_GFP vs Time")) +
  scale_color_manual(name = "Simulation type",
                     breaks = c("Simulated_max", "Simulated_mean","Simulated_min", "Experiments_mean(Sd)"),
                     values = c("Simulated_max" = "red", "Simulated_mean" = "blue", "Simulated_min" = "green","Experiments_mean(Sd)" = "black"))+
  theme(legend.title = element_blank()) + theme(legend.position="bottom") +
  theme(legend.text = element_text(size= 8,face="bold")) 

png(paste0(directory,"/", Drug[i],"_",Exp[j],"_Srxn1",".png"), width = 700, height = 480)
print(plot)
dev.off() 

}}

# plot for Fraction_X for repeated scenarios

png(paste0(directory,"/", "Repeated_Fraction_X",".png"), width = 600, height = 480)
final %>% 
  ggplot(aes(x = time, y = Fraction_X_mean,color= as.factor(Experiment))) +
  geom_line(size = 1,lty = 2) +
  facet_wrap(~Treament) +
  labs(x = "Time (hr)",y="Fraction_X", title = paste0("Repeated_Fraction_X vs Time"))

dev.off() 

# plotting code for observed vs predicted for repeated scenarios

png(paste0(directory,"/", "Repeated_Obs_Vs_Predicted",".png"), width = 700, height = 500)
par(mfrow = c(4,2))
for (i in 1:4){
  final1 = final %>% filter(.,Treament == Drug[i]) %>% filter(.,Experiment == Exp[1]) 
  R_square <- cor(final1$SRXN1_observed, final1$Srxn1_mean)^2
  plot(final1$SRXN1_observed, final1$Srxn1_mean,
       xlim = c(0.1, 45), ylim = c(0.1, 45),
       xlab = "Observed", ylab = "Predicted",
       main = paste(Exp[1],Drug[i],"(R2 =", round(R_square, digits = 3),")"))
  abline(0,1)
  
}
for (i in 1:4){
  final1 = final %>% filter(.,Treament == Drug[i]) %>% filter(.,Experiment == Exp[2]) %>% na.omit()
  R_square <- cor(final1$SRXN1_observed, final1$Srxn1_mean)^2
  plot(final1$SRXN1_observed, final1$Srxn1_mean,
       xlim = c(0.1, 65), ylim = c(0.1, 65),
       xlab = "Observed", ylab = "Predicted",
       main = paste(Exp[2],Drug[i],"(R2 =", round(R_square, digits = 3),")"))
  abline(0,1)
  
}
dev.off() 

#######################################

continous_data_48 = myfiles[c("Andrographolide_Conti_48.txt","Sulforaphane_Conti_48.txt", "CDDO_me_Conti_48.txt","Ethacrynic_Acid_Conti_48.txt")]
continous_data_32 = myfiles[c("Andrographolide_Conti_32.txt" , "Sulforaphane_Conti_32.txt", "CDDO_me_Conti_32.txt","Ethacrynic_Acid_Conti_32.txt")]

continous_data_32$Andrographolide_Conti_32.txt$Treament = rep("Andro", length(continous_data_32$Andrographolide_Conti_32.txt$Srxn1_max))
continous_data_32$Sulforaphane_Conti_32.txt$Treament = rep("Sul", length(continous_data_32$Andrographolide_Conti_32.txt$Srxn1_max))
continous_data_32$CDDO_me_Conti_32.txt$Treament = rep("CDDO", length(continous_data_32$Andrographolide_Conti_32.txt$Srxn1_max))
continous_data_32$Ethacrynic_Acid_Conti_32.txt$Treament = rep("ETA", length(continous_data_32$Andrographolide_Conti_32.txt$Srxn1_max))

Df = do.call("rbind", list(continous_data_32$Andrographolide_Conti_32.txt,continous_data_32$Sulforaphane_Conti_32.txt,continous_data_32$CDDO_me_Conti_32.txt,continous_data_32$Ethacrynic_Acid_Conti_32.txt))

Df$Experiment = rep("8_24_continous",length(Df$NRF2_max))

Df$dose2 = rep(0,length(Df$NRF2_max))

continous_data_48$Andrographolide_Conti_48.txt$Treament = rep("Andro", length(continous_data_48$Andrographolide_Conti_48.txt$Srxn1_max))
continous_data_48$Sulforaphane_Conti_48.txt$Treament = rep("Sul", length(continous_data_48$Sulforaphane_Conti_48.txt$Srxn1_max))
continous_data_48$CDDO_me_Conti_48.txt$Treament = rep("CDDO", length(continous_data_48$Sulforaphane_Conti_48.txt$Srxn1_max))
continous_data_48$Ethacrynic_Acid_Conti_48.txt$Treament = rep("ETA", length(continous_data_48$Ethacrynic_Acid_Conti_48.txt$Srxn1_max))

Df2 = do.call("rbind", list(continous_data_48$Andrographolide_Conti_48.txt,continous_data_48$Sulforaphane_Conti_48.txt,
                            continous_data_48$CDDO_me_Conti_48.txt,continous_data_48$Ethacrynic_Acid_Conti_48.txt))

Df2$Experiment = rep("24_24_continous",length(Df2$NRF2_max))

Df2$dose2 = rep(0,length(Df2$NRF2_max))


final2 = data.frame(Df2)
Drug = unique(Df2$Treament)
Exp = unique(Df2$Experiment)


Df3 = do.call("rbind", list(Finalplotdata, Df2))    #combine repeated dosing and 24+24 continous scenario
Drug = unique(Df3$Treament)
Exp = unique(Df3$Experiment)

png(paste0(directory,"/", "Continous_Fraction_X",".png"), width = 600, height = 480)
final2 %>% 
  ggplot(aes(x = time, y = Fraction_X_mean)) +
  geom_line(size = 1,lty = 2) +
  facet_wrap(~Treament) +
  labs(x = "Time (hr)",y="Fraction_recruitment X", title = paste0("Continous_Fraction_X vs Time"))
dev.off()

# Comparative_plot of Fraction_X for different scenarios and different drugs

png(paste0(directory,"/", "Comparative_plot_Fraction_X",".png"), width = 600, height = 480)
ggplot(Df3, (aes(x = time, y = Fraction_X_mean,group=interaction(Experiment))))+
  geom_line(aes(color=Experiment))+
  facet_grid(Second~First)+
  labs(x = "Time (hr)",y="Fraction_recruitment_X", title = paste0("Fraction_X vs Time")) +
  facet_wrap(~Treament) 

dev.off()


Df4 = do.call("rbind", list(Df, Df2))  # combine both continous scenarios
glimpse(Df4)
Dose1 = c(35,100,100,1)
Drug = c("Sul" ,"Andro","ETA","CDDO")
Exp = unique(Df4$Experiment)

for (i in 1:4){
plot = Df4 %>% filter(.,Treament == Drug[i]) %>% filter(.,Experiment == Exp[2]) %>% 
  filter(.,dose1 != Dose1[i])  %>% 
  ggplot() +
  geom_line(aes(x = time, y = Srxn1_max, color = "Simulated_max"),size=1) +
  geom_line(aes(x = time, y = Srxn1_mean, color="Simulated_mean"),size=1) +
  geom_line(aes(x = time, y = Srxn1_min, color="Simulated_min"),size=1) +
  geom_errorbar(aes(x = time, ymin=SRXN1_observed-SRXN1_SD, ymax= SRXN1_observed +SRXN1_SD,color = "Experiments_mean(Sd)"), size=0.5,   
                width=.25) + 
  facet_wrap(~dose1) +
  labs(x = "Time (hr)",y="GFP intensity", title = paste0(Exp[2],"_", Drug[i],"_GFP vs Time"))+
  scale_color_manual(name = "Simulation type",
                     breaks = c("Simulated_max", "Simulated_mean","Simulated_min", "Experiments_mean(Sd)"),
                     values = c("Simulated_max" = "red", "Simulated_mean" = "blue", "Simulated_min" = "green","Experiments_mean(Sd)" = "black"))+
  theme(legend.title = element_blank()) + theme(legend.position="bottom") +
  theme(legend.text = element_text(size= 8,face="bold")) 
print(plot)
}


# Plot all the chemical in one graph

png(paste0(directory,"/",Exp[1],"_Continous",".png"), width = 700, height = 480)
Df4 %>%  filter(.,Experiment == Exp[1]) %>% 
  ggplot() +
  geom_line(aes(x = time, y = Srxn1_max, color = "Simulated_max"),size=1) +
  geom_line(aes(x = time, y = Srxn1_mean, color="Simulated_mean"),size=1) +
  geom_line(aes(x = time, y = Srxn1_min, color="Simulated_min"),size=1) +
  geom_errorbar(aes(x = time, ymin=SRXN1_observed-SRXN1_SD, ymax= SRXN1_observed +SRXN1_SD,color = "Experiments_mean(Sd)"), size=0.5,   
                width=.25) +  
  facet_wrap(Treament~dose1,ncol = 6) +
  labs(x = "Time (hr)",y="GFP intensity", title = paste0(Exp[1],"_GFP vs Time"))+
  scale_color_manual(name = "Simulation type",
                     breaks = c("Simulated_max", "Simulated_mean","Simulated_min", "Experiments_mean(Sd)"),
                     values = c("Simulated_max" = "red", "Simulated_mean" = "blue", "Simulated_min" = "green","Experiments_mean(Sd)" = "black"))+
  theme(legend.title = element_blank()) + theme(legend.position="bottom") +
  theme(legend.text = element_text(size= 8,face="bold")) 

dev.off()

png(paste0(directory,"/", "Conti_Obs_Vs_Predicted",".png"), width = 700, height = 500)
par(mfrow = c(4,2))
for (i in 1:4){
  final1 = Df4 %>% filter(.,Treament == Drug[i]) %>% filter(.,Experiment == Exp[1]) 
  R_square <- cor(final1$SRXN1_observed, final1$Srxn1_mean)^2
  plot(final1$SRXN1_observed, final1$Srxn1_mean,
       xlim = c(0.1, 60), ylim = c(0.1, 60),
       xlab = "Observed", ylab = "Predicted",
       main = paste(Exp[1],Drug[i],"(R2 =", round(R_square, digits = 3),")"))
  abline(0,1)
  
}
for (i in 1:4){
  final1 = Df4 %>% filter(.,Treament == Drug[i]) %>% filter(.,Experiment == Exp[2]) 
  R_square <- cor(final1$SRXN1_observed, final1$Srxn1_mean)^2
  plot(final1$SRXN1_observed, final1$Srxn1_mean,
       xlim = c(0.1, 60), ylim = c(0.1, 60),
       xlab = "Observed", ylab = "Predicted",
       main = paste(Exp[2],Drug[i],"(R2 =", round(R_square, digits = 3),")"))
  abline(0,1)
  
}

dev.off()
